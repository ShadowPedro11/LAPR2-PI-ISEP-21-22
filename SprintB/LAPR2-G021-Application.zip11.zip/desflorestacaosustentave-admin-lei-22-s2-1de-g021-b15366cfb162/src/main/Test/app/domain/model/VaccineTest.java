package app.domain.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class VaccineTest {

    @Test
    void validateNoNullCreation() {
        Vaccine vaccine = new Vaccine(null, null, null);
        boolean actual = Company.validateVaccine(vaccine);
        assertFalse(actual);
    }
}