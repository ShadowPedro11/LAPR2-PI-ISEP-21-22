package app.domain.model;

public class CenterCoordinator extends Employee {

    public CenterCoordinator(String name, String address, int phoneNumber, String email, int citizenCardNumber){
        super(name, address, phoneNumber, email, citizenCardNumber);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
