package app.domain.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class VaccineAdministrationTest {

    /*
    @Test
    void validateNoNullCreation() {
        VaccineAdministration vaccineAdministration = new VaccineAdministration(0, 0, 0, 0,0);
        boolean actual = Company.validateVaccineAdministration(vaccineAdministration);
        assertFalse(actual);
    }

     */
}