package app.ui.console;

/**
 *
 * @author Paulo Maio <pam@isep.ipp.pt>
 */
public class DevTeamUI implements Runnable{

    public DevTeamUI()
    {

    }
    public void run()
    {
        System.out.println("\n");
        System.out.printf("Development Team:\n");
        System.out.printf("\t Student Name 1 - 120XXXX@isep.ipp.pt \n");
        System.out.printf("\t Student Name 2 - 120XXXX@isep.ipp.pt \n");
        System.out.printf("\t Student Name 3 - 120XXXX@isep.ipp.pt \n");
        System.out.printf("\t Student Name 4 - 120XXXX@isep.ipp.pt \n");
        System.out.println("\n");
    }
}
