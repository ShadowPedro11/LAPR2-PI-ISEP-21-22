# Glossary

**Terms, Expressions and Acronyms (TEA) must be organized alphabetically.**

(To complete according the provided example)

| **_TEA_** (EN)  | **_TEA_** (PT) | **_Description_** (EN)                                           |                                       
|:------------------------|:-----------------|:--------------------------------------------|
| **Clerk** | **Administrativo** | Person responsible for carrying out various business supporting activities on the system. |
| **CLK** | **ADM** | Acronym for _Clerk_.|
| **...** | **...** | ...|








