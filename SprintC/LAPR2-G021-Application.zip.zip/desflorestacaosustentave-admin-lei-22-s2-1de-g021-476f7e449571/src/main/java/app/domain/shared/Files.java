package app.domain.shared;

public class Files {


    public static final String FILE_USERS_BIN = "users.bin";

    public static final String FILE_EMPLOYEE_BIN = "employees.bin";

    public static final String FILE_VACCINATION_CENTERS = "vaccination_centers.bin";

    public static final String FILE_VACCINE_TYPE = "vaccine_type.bin";

    public static final String FILE_VACCINE = "vaccine.bin";

    public static final String FILE_ADMINISTRATION_PROCESS = "administration_processes.bin";

    public static final String FILE_VACCINE_SCHEDULE_STORE = "vaccine_schedule_store";

}
